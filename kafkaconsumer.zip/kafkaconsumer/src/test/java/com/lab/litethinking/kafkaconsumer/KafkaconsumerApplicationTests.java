package com.lab.litethinking.kafkaconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
